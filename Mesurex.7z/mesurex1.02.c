
task main()
{

while(1){

if(getButtonPress(buttonUp)==true){
	SensorType[S1] = sensorEV3_Touch;
	int angle = 0;
	resetMotorEncoder(motorA);
	while (SensorValue[S1]==0){
		setMotorSpeed(motorA,10);
	}
	stopMotor(motorA);
	float n;
	n = getMotorEncoder(motorA);
	float tours_motorA=n/360;
	float distance_motorA=tours_motorA*18.3;
	displayCenteredBigTextLine (4, "Distance: %f cm", moyenneDistance);

	sleep(10000);






}
