//################################################
//Projet Mesurex V. 1.03
//
//Auteurs: Lazare Viennot et PHAN Nu Uyen Thi
//
//Date: 06/03/2019
//
//DESCRIPTION / MANUEL:
//Ce programme � pour but de contr�ler un robot mesurant
//des distances.
//Quand l'utilisateur presse le bouton du haut, le robot
//se d�place tout droit jusqu'� rencontrer un obstacle(quand le capteur de contact touche un objet)
//Il affiche ensuite la distance parcourue sur l'�cran, en centim�tres (cm).
//###############################################

#include "hitechnic-angle.h"
//D�claration du capteur d'angle

void  marche_avant(){    //on d�clare la fonction
  tHTANG angleSensor;
  int vitesse;
 	initSensor(&angleSensor, S1);
	SensorType[S2] = sensorEV3_Touch;
	while (SensorValue[S2]==0){
		setMotorSpeed(motorA,vitesse);
		setMotorSpeed(motorD,vitesse); //On d�marre les moteur � vitesse 10 tant que le capteur de contact n'est pas activ�
	}
	stopMotor(motorA);
	stopMotor(motorD);
	float n;
	readSensor(&angleSensor); //on r�cup�re l'angle total mesur� par le capteur
	n=angleSensor.accumlatedAngle;
	n=n*(-1); //on inverse la valeur de l'angle (le capteur est � l'envers)
	float tours_sensor=n/360;//on calcule le nombre de tour parcourus par les roues
	float distance_sensor=(tours_sensor*17.6); //on calcule la distance d'apr�s la circonf�rence des roues (17.6cm)
	displayCenteredBigTextLine (3, "Distance: ");
	displayCenteredBigTextLine (5, "%f cm", distance_sensor);//on affiche � l'�cran la distance parcourue
	}
task main(){

#ifdef NXT
  nNxtButtonTask  = -2;
#endif
tHTANG angleSensor;
 	initSensor(&angleSensor, S1);

while(1){
	if(getButtonPress(buttonUp)==true){//Si on appuye sur [avant], on enclenche la fonction "marche_avant"
		resetSensor(&angleSensor);
    int vitesse=10;
		marche_avant();
		sleep(1000);
	}

	if(getButtonPress(buttonDown)==true){//Si on appuye sur [arri�re], on enclenche la fonction "marche_avant"
		resetSensor(&angleSensor);
		int vitesse=-10;
		marche_avant();
		sleep(1000);
	}
		if(getButtonPress(buttonRight)==true){ //On remet � 0 toutes les valeurs des variables
			int n=0;
			int tours_sensor=0;
			int distance_sensor=0;
		  resetSensor(&angleSensor);
		}
	}

}
