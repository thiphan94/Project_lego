#include "hitechnic-angle.h"


void  marche_avant(){
  tHTANG angleSensor;
 	initSensor(&angleSensor, S1);
	SensorType[S2] = sensorEV3_Touch;



	while (SensorValue[S2]==0){
		setMotorSpeed(motorA,10);
		setMotorSpeed(motorD,10);
	}
	stopMotor(motorA);
	stopMotor(motorD);
	float n;
	readSensor(&angleSensor);
	n=angleSensor.accumlatedAngle;
	float tours_sensor=n/360;
	float distance_sensor=(tours_sensor*17.6);
	distance_sensor=((distance_sensor*distance_sensor)/distance_sensor);
	displayCenteredBigTextLine (4, "Distance: %f cm", distance_sensor);
  //displayTextLine(3, "Tot: %7d deg", angleSensor.accumlatedAngle);
	//displayCenteredTextLine (4, "N=: %f ", n);
	}


task main()
{
#ifdef NXT
  nNxtButtonTask  = -2;
#endif
tHTANG angleSensor;
 	initSensor(&angleSensor, S1);

while(1){
	if(getButtonPress(buttonUp)==true){
		resetSensor(&angleSensor);
		marche_avant();
		sleep(1000);
	}
		if(getButtonPress(buttonRight)==true){
			int n=0;
			int tours_sensor=0;
			int distance_sensor=0;
		  resetSensor(&angleSensor);
		}
	}

}
